/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package herencia;

/**
 *
 * @author Usuario
 */
public class Herencia {
public Herencia (String matricula, double promedio){}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        persona per =new Profesor();
        per.setnombre_completo("Elizabeth Montoro Hernández");
        per.setfecha_nacimiento("15 de febrero del 2002");
        per.setdomicilio("");
        System.out.print(per.mostrarDatos());
        per.mostrarDatos();
        
        Estudiante obj1 =new Estudiante();
        obj1.setmatricula("222110716");
        obj1.setpromedio(9.6);
        System.out.print(obj1.mostrarDatos());
        obj1.mostrarDatos();
        
        Profesor Pr =new Profesor();
        Pr.settitulo("12");
        Pr.setcedulap(9);
        System.out.print(Pr.mostrarDatos());
        Pr.mostrarDatos();
        
        
    }

}
