/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author Usuario
 */
public class Estudiante extends persona{
    String matricula;
    double promedio;
    
    
    
    public Estudiante(){}
    public Estudiante(String nombre_completo,String fecha_nacimiento, String domicilio, String matricula, double promedio){
        super(nombre_completo,fecha_nacimiento,domicilio);
        this.matricula=matricula;
        this.promedio=promedio;
    }
    public String getmatricula() {
        return matricula;
    }
    public double getpromedio() {
        return promedio;
    }

    public void setmatricula(String matricula) {
        this.matricula = matricula;
    }

    public void setpromedio(double promedio) {
        this.promedio = promedio;
    }
    public String mostrarDatos(){
        return super.mostrarDatos()+"Matricula: "+matricula+ "Promedio: "+promedio; 
    }

}
