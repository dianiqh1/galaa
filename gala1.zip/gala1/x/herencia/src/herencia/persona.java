/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author Usuario
 */
public class persona {
    String nombre_completo;
    String fecha_nacimiento;
    String domicilio;
    
    
    public persona(){}
    public persona (String nombre_completo, String fecha_nacimiento, String domicilio){
        this.nombre_completo=nombre_completo;
        this.fecha_nacimiento=fecha_nacimiento;
        this.domicilio=domicilio;
    }
    public String getnombre_completo(){
        return nombre_completo;
    }
    public String getfecha_nacimiento(){
        return fecha_nacimiento;
    }
    public String getdomicilio(){
        return domicilio;
    }
    public void setnombre_completo(String nombre_completo){
        this.nombre_completo=nombre_completo;
    }
    public void setfecha_nacimiento(String fecha_nacimiento){
        this.fecha_nacimiento=fecha_nacimiento;
    }
    public void setdomicilio(String domicilio){
        this.domicilio=domicilio;
    }
    public String mostrarDatos(){
        return "Nombre completo: "+nombre_completo+ "Fecha de nacimiento: "+fecha_nacimiento+ " Domicilio: " +domicilio; 
    }
}
