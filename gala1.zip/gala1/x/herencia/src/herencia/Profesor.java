/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author Usuario
 */
public class Profesor extends persona{
    String titulo;
    int cedulap;
    
    
    
    public Profesor(){}
    public Profesor (String nombre_completo, String fecha_nacimiento, String domicilio, String titulo, int cedulap){
        super(nombre_completo,fecha_nacimiento,domicilio);
        this.titulo=titulo;
        this.cedulap=cedulap;
    }
    public String gettitulo(){
        return titulo;
    }
    public int getcedula(){
        return cedulap;
    }

    public void settitulo(String titulo) {
        this.titulo=titulo;
    }
    public void setcedula(int cedulap) {
        this.cedulap=cedulap;
    }
    @Override
    public String mostrarDatos(){
        return super.mostrarDatos()+"eres: "+titulo+ "con cédula: "+cedulap; 
    }
}
