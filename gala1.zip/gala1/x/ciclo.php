<?php

echo "Liz","<br>";
$incremento=2;
$num=2;
while($num<=500){
    echo",".$num;
    $num=$num+$incremento;
}
?>