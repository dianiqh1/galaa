/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacion;

/**
 *
 * @author Usuario
 */
public class Cuadrado extends Figuras{
    int area, perimetro;
    
    public Cuadrado(){}
    public Cuadrado(int base, String color, String nombre,int area, int perimetro){
        super(base,color,nombre);
        this.area=area;
        this.perimetro=perimetro;
    }

    public int getarea() {
        return area;
    }

    public int getperimetro() {
        return perimetro;
    }

    public void setarea(int area) {
        this.area = area;
    }

    public void setperimetro(int perimetro) {
        this.perimetro = perimetro;
    }
   
    
    
@Override
    public String mostrarDatos(){
        return super.mostrarDatos()+"Matricula: "+area+ "Promedio: "+perimetro; 
    }

}

    
    

