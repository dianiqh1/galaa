/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacion;
public class Rectangulo extends Figuras{
    
    int altura;
    
    
    public Rectangulo(){}
    
    public Rectangulo(int altura){
        this.altura=altura;
    }
    public int getaltura() {
        return altura;
    }
    public void setaltura(String cambiacolor) {
        this.altura = altura;
    }
    
    public int obtenerhipotenusa(){
        int hipotenusa=0;
        return hipotenusa; 
    }  
@Override
    public String mostrarDatos(){
        return "La altura es: " +altura; 
    }  
}