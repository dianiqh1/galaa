/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacion;


public class Figuras{
    int base;
    String color;
    String nombre;
    

/**
 *
 * @author Usuario
 */
public Figuras(){}

    public Figuras (int base, String color, String nombre){
        this.base=base;
        this.color=color;
        this.nombre=nombre;
        
    }

    public int getbase() {
        return base;
    }

    public String getcolor() {
        return color;
    }

    public String getnombre() {
        return nombre;
    }

    

    public void setbase(int base) {
        this.base = base;
    }

    public void setcolor(String color) {
        this.color = color;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    
    
    public String mostrarDatos(){
        return "El nombre de tu figura es: " +nombre+ " El color de tu figura es: " +color; 
    }
}