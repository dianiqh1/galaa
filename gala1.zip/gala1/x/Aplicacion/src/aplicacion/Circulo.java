/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Aplicacion;
public class Circulo extends Figuras{
    
    int area, perimetro;
    String cambiacolor;
    
    public Circulo(){}
    public Circulo(int area, int perimetro, String cambiacolor){
        this.area=area;
        this.perimetro=perimetro;
        this.cambiacolor=cambiacolor;
    }

    public int getArea() {
        return area;
    }

    public int getPerimetro() {
        return perimetro;
    }

    public String getCambiacolor() {
        return cambiacolor;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public void setPerimetro(int perimetro) {
        this.perimetro = perimetro;
    }

    public void setCambiacolor(String cambiacolor) {
        this.cambiacolor = cambiacolor;
    }
    
    public int obternerarea(){
        double pi = 3.1416;
        area=(int) (base*pi);
        return area;
    }
    
    public int obtenerperimetro(){
        double pi=3.1416;
        perimetro=(int) (pi*base*base);
        return perimetro;
    }
    
    
@Override
    public String mostrarDatos(){
        return "El área es: "+area+ "El perimetro es: "+perimetro+ "El color es: " +cambiacolor; 
    }  
}
        