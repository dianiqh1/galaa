<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "circos";

$NombreCirco=$_POST['NombreCirco'];
$DueñoCirco=$_POST['DueñoCirco'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO circos (NombreCirco, DueñoCirco)
VALUES ('".$NombreCirco."', '".$DueñoCirco."')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

<html>
    <head></head>
    <body>
        <form action="Alta.php" method= "post">
            Ingrese un nombre de un circo:
            <input type="text" name="NombreCirco">
                <br>
                Ingrese el nombre del dueño del circo:
            <input type="text" name="DueñoCirco">
                <br>
            <button type="submit" >GUARDAR </button>
</form>



    <a href="agregarr.php">Agregar</a>					
				<br><br>	
				<table>
					<thead>
						<tr>
							<th>ID</th>
							<th>Nombre del circo</th>
							<th>Dueño del circo</th>
							<th>Acciones</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>



              <?php
//validamos datos del servidor
$user = "root";
$pass = "";
$host = "localhost";

//conetamos al base datos
$connection = mysqli_connect($host, $user, $pass);
        //indicamos el nombre de la base datos
        $datab = "circos";
        //indicamos selecionar ala base datos
        $db = mysqli_select_db($connection,$datab);
        //insertamos datos de registro al mysql xamp, indicando nombre de la tabla y sus atributos
        $instruccion_SQL = "INSERT INTO circos (id, NombreCirco, DueñoCirco)
                             VALUES ('')";
                           
                            
        $resultado = mysqli_query($connection,$instruccion_SQL);

        //$consulta = "SELECT * FROM tabla where id ='2'"; si queremos que nos muestre solo un registro en especifivo de ID
        $consulta = "SELECT * FROM circos";
        
$result = mysqli_query($connection,$consulta);
if(!$result) 
{
    echo "No se ha podido realizar la consulta";
}


while ($colum = mysqli_fetch_array($result))
 {
    echo "<tr>";
    echo "<td>" . $colum['ID']. "</td>";
    echo "<td>" . $colum['NombreCirco']. "</td>";
    echo "<td>" . $colum['DueñoCirco'] . "</td>";
    echo "<td>". '<a href="editar.php">Editar</a>' . "</td>";
    echo "<td>" ."<a href='eliminar.php?id=".$colum['ID']."'>Eliminar</a>" . "</td>";
    echo "</tr>";
}
echo "</table>";

mysqli_close( $connection );

  

?>


</body>
</html>