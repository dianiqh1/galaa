/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplom1;

/**
 *
 * @author Usuario
 */
public class Tablas_de_multiplicar {
    public static void main(String[] args) {
        Tablas_de_multiplicar p1= new Tablas_de_multiplicar();
        p1.mostrardatos(8);
        
    }
    
    public void mostrardatos(int n){
        for(int i=1; i<=10; i++){
            System.out.println(n+ " * " +i + "=" + n*i);
        }
        
    }
}
