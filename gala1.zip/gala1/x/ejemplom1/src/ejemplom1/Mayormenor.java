/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplom1;

/**
 *
 * @author Usuario
 */
public class Mayormenor {
     public static void main(String[] args) {
        Mayormenor p1= new Mayormenor();
        System.out.println(p1.mostrardatos(15));
    }

    public String mostrardatos(int n){
        String men;
        if(n>=18){
        men= "Eres mayor de edad";
        }
        else{
        men= "Eres menor de edad";
        }
        return men;
        
    }
}
