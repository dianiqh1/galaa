/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplom1;
import java.util.*;
/**
 *
 * @author Usuario
 */
public class Ejemplom1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ejemplom1 p1= new Ejemplom1();
        p1.mostrardatos();
        
    }
    public void mostrardatos(){
      Scanner en=new Scanner (System.in);
      String nombre, sexo, edad;
      System.out.println("¿Cuál es tu nombre?");
      nombre=en.next();
      System.out.println("¿Cuál es tu sexo?");
      sexo=en.next();
      System.out.println("¿Cuál es tu edad?");
      edad=en.next();
      System.out.println("Te llamas: " +nombre +" eres " +sexo +" tienes " +edad + " años ");
    }
}
